﻿namespace Helloworld
{
    class Program
    {

        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();

            Manufacture m = new Manufacture();

            m.Load("lr11_12.csv");

            
            Console.ReadKey();
        }

    }
    public class Manufacture
        {
            public Manufacture()
            {
            }
            String ID {get; set;}
            String Name {get; set;}
            String Category {get; set;}
            public float Salary {get; set;}
            public float Count {get; set;}
            public float Price {get; set;}
            public float Substract;

            public Boolean Load(string pFileName)
            {
                if (File.Exists(pFileName))
                {       
                        StreamReader f_in = new StreamReader(pFileName);         
                        List<Manufacture> all = new List<Manufacture>();
                        try
                        {

                            String line = f_in.ReadLine();
                            while((line = f_in.ReadLine()) != null)
                                {
                                    all.Add(Manufacture.Create(line));
                                }      
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
#if !DEBUG
                        TextWriter save_out = Console.Out;
                        var new_out = new StreamWriter(@"LR_11_OUT.txt");
                        Console.SetOut(new_out);

                        foreach (var m in all)
                            Console.WriteLine(m);

                        Console.SetOut(save_out);
                        new_out.Close();
#endif
                        Console.WriteLine("*******Задача 1********");
                        int Counter = all.FindAll(m => m.Count * m.Price < m.Salary).ToList().Count;
                        Console.WriteLine("Количество сотрудников у которых з/п больше произведённой продукции: {0} \n", Counter);

                        Console.WriteLine("*******Задача 2********");
                        float Sum = 0;
                        for(int i = 0; i < all.Count; i++)
                            Sum += all[i].Count * all[i].Price;
                        Console.WriteLine("Общий объём произведённой продукции (в валюте): {0} $\n", Sum);
                        
                        Console.WriteLine("*******Задача 3********");
                        float SumA = 0;
                        float SumB = 0;
                        float SumC = 0;
                        float SumD = 0;
                        for(int i = 0; i < all.Count; i++)
                            {
                            if(all[i].Category == "A")
                                SumA += all[i].Count * all[i].Price;

                            else if(all[i].Category == "B")
                                SumB += all[i].Count * all[i].Price;

                            else if(all[i].Category == "C")
                                SumC += all[i].Count * all[i].Price;

                            else
                                SumD += all[i].Count * all[i].Price;
                            }
                        Console.WriteLine("Общий объём произведённой продукции типа А (в валюте): {0} $\n"+
                                        "Общий объём произведённой продукции типа B (в валюте): {1} $\n"+
                                        "Общий объём произведённой продукции типа C (в валюте): {2} $\n"+
                                        "Общий объём произведённой продукции типа D (в валюте): {3} $\n",
                                        SumA, SumB, SumC, SumD);

                        Console.WriteLine("*******Задача 4********");
                            float maxE = 0;
                            int ind = 0;
                            for (int i = 0; i < all.Count; i++)
                                    if (maxE < all[i].Substract)
                                    {
                                        maxE = all[i].Substract;
                                        ind = i;
                                    }
                                    else maxE = maxE;

                            Console.WriteLine("Данные сотрудника с максимальной эффективностью: {0}\n\n"+
                                            "Эффективность сотрудника: {1}\n", all[ind], maxE);
                }
                return false;

            }

            public static Manufacture Create(string str)
            {
                Manufacture m = new Manufacture();
                string[] e = str.Split(',');
                m.ID = e[0].Trim();
                m.Name = e[1].Trim();
                m.Category = e[2].Trim();
                m.Salary = Convert.ToSingle(e[3].TrimStart('$').Replace('.',','));
                m.Count = Convert.ToSingle(e[4].Trim());
                m.Price = Convert.ToSingle(e[5].TrimStart('$').Replace('.',','));
                m.Substract = (m.Count * m.Price - m.Salary);

                return m;
            }
            public override string ToString()
            {
                String s = string.Format(
                    "***************************************************\n"+
                    "ID: {0}, Name: {1}, Category: {2}\n"+
                    "Salary: {3}, Count: {4}, Price: {5}",
                    ID,Name,Category,Salary,Count,Price);

                    return s;
            }
        }
}
  